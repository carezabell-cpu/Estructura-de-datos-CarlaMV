let msj = "Datos Arte Código";

// console.log(msj.substring(6,10));

console.log("posicion de Código: "+ msj.indexOf("Código"))

let msjArray = msj.split(" ");
// console.log(msj.split(" "));
// console.log(msjArray.length);
